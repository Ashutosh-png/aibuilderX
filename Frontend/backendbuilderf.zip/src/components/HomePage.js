import React, { useState } from 'react';
import axios from 'axios';

const HomePage = () => {
  const [selectedLanguage, setSelectedLanguage] = useState(null);
  const [prompt, setPrompt] = useState('');
  const [responseMessage, setResponseMessage] = useState('');
  const [generatedCode, setGeneratedCode] = useState(null);

  const languages = [
    { label: "Python", value: "python" },
    { label: "Node.js", value: "node.js" },
    { label: "Ruby", value: "ruby" },
    { label: "Java", value: "java" },
    { label: "PHP", value: "php" },
    { label: "Go", value: "go" },
  ];

  const handleLanguageChange = (event) => {
    setSelectedLanguage(event.target.value);
  };

  const handleSubmit = async () => {
    try {
      const response = await axios.post('http://127.0.0.1:5000/generate_code', {
        prompt,
        language: selectedLanguage,
      });
      setResponseMessage('Code generated successfully!');
      setGeneratedCode(response.data);
    } catch (error) {
      console.error(error);
      setResponseMessage('Error generating code');
      setGeneratedCode(null);
    }
  };

  const handleDownload = () => {
    if (generatedCode) {
      const blob = new Blob([generatedCode.code], { type: 'text/plain;charset=utf-8' });
      const url = window.URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.download = `generated_api_code.${generatedCode.extension}`;
      link.click();
      window.URL.revokeObjectURL(url);
    }
  };

  return (
    <div className="container mt-5">
      <h1 className="mb-4">Select Programming Language</h1>
      <div className="form-group">
        {languages.map((lang) => (
          <div className="form-check form-check-inline" key={lang.value}>
            <input
              type="radio"
              className="form-check-input"
              value={lang.value}
              checked={selectedLanguage === lang.value}
              onChange={handleLanguageChange}
              id={`radio-${lang.value}`}
            />
            <label className="form-check-label" htmlFor={`radio-${lang.value}`}>
              {lang.label}
            </label>
          </div>
        ))}
      </div>

      {generatedCode && (
        <div className="mt-4">
          <h5>Generated Code:</h5>
          <pre className="bg-light p-3 rounded">{generatedCode.code}</pre>
          <button onClick={handleDownload} className="btn btn-primary">Download Project File</button>
        </div>
      )}

      {responseMessage && <p className="mt-3">{responseMessage}</p>}

      <div className="form-group mt-4">
        <textarea
          placeholder="Enter your project prompt..."
          value={prompt}
          onChange={(e) => setPrompt(e.target.value)}
          className="form-control"
          rows="5"
        />
      </div>

      <button onClick={handleSubmit} className="btn btn-primary mt-3">
        Create
      </button>
    </div>
  );
};

export default HomePage;